// Copyright (c) 2016, Charles Lechasseur
// Distributed under the MIT license (see LICENSE).

// Forward header for cl/optional/optional.h

#ifndef CL_OPTIONAL_FWD_H
#define CL_OPTIONAL_FWD_H

#include <cl/optional/optional.h>

#endif // CL_OPTIONAL_FWD_H
