﻿namespace PathCopyCopy.Settings.UI.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ApplyBtn = new System.Windows.Forms.Button();
            this.OKBtn = new System.Windows.Forms.Button();
            this.CancelBtn = new System.Windows.Forms.Button();
            this.MainTabCtrl = new System.Windows.Forms.TabControl();
            this.PluginsPage = new System.Windows.Forms.TabPage();
            this.AddSeparatorBtn = new System.Windows.Forms.Button();
            this.ImportPipelinePluginsBtn = new System.Windows.Forms.Button();
            this.ExportPipelinePluginsBtn = new System.Windows.Forms.Button();
            this.BevelLineLbl2 = new System.Windows.Forms.Label();
            this.RemovePipelinePluginBtn = new System.Windows.Forms.Button();
            this.EditPipelinePluginBtn = new System.Windows.Forms.Button();
            this.AddPipelinePluginBtn = new System.Windows.Forms.Button();
            this.BevelLineLbl = new System.Windows.Forms.Label();
            this.MovePluginDownBtn = new System.Windows.Forms.Button();
            this.MovePluginUpBtn = new System.Windows.Forms.Button();
            this.PreviewGroupBox = new System.Windows.Forms.GroupBox();
            this.PreviewTxt = new System.Windows.Forms.TextBox();
            this.PluginsExplanationLbl2 = new System.Windows.Forms.Label();
            this.PluginsDataGrid = new System.Windows.Forms.DataGridView();
            this.IconCol = new System.Windows.Forms.DataGridViewImageColumn();
            this.PluginCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.InMainMenuCol = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.InSubmenuCol = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.PluginsExplanationLbl = new System.Windows.Forms.Label();
            this.MiscOptionsPage = new System.Windows.Forms.TabPage();
            this.EncodeURICharsChk = new System.Windows.Forms.CheckBox();
            this.EncodeURIWhitespaceChk = new System.Windows.Forms.CheckBox();
            this.CopyOnSameLineChk = new System.Windows.Forms.CheckBox();
            this.DropRedundantWordsChk = new System.Windows.Forms.CheckBox();
            this.UsePreviewModeChk = new System.Windows.Forms.CheckBox();
            this.UseIconForSubmenuChk = new System.Windows.Forms.CheckBox();
            this.EmailLinksChk = new System.Windows.Forms.CheckBox();
            this.EnableSoftwareUpdateChk = new System.Windows.Forms.CheckBox();
            this.AlwaysShowSubmenuChk = new System.Windows.Forms.CheckBox();
            this.HiddenSharesChk = new System.Windows.Forms.CheckBox();
            this.AddQuotesChk = new System.Windows.Forms.CheckBox();
            this.AboutPage = new System.Windows.Forms.TabPage();
            this.AboutTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.ProductAndVersionLbl = new System.Windows.Forms.Label();
            this.CopyrightLbl = new System.Windows.Forms.Label();
            this.VisitWebsiteLbl = new System.Windows.Forms.Label();
            this.SiteLinkLbl = new System.Windows.Forms.LinkLabel();
            this.LicenseExplanationLbl = new System.Windows.Forms.Label();
            this.LicenseTxtLinkLbl = new System.Windows.Forms.LinkLabel();
            this.DonationLinkLbl = new System.Windows.Forms.LinkLabel();
            this.ExportPipelinePluginsSaveDlg = new System.Windows.Forms.SaveFileDialog();
            this.ImportPipelinePluginsOpenDlg = new System.Windows.Forms.OpenFileDialog();
            this.ChoosePluginIconOpenDlg = new System.Windows.Forms.OpenFileDialog();
            this.ExportUserSettingsSaveDlg = new System.Windows.Forms.SaveFileDialog();
            this.ExportUserSettingsBtn = new System.Windows.Forms.Button();
            this.MainToolTip = new System.Windows.Forms.ToolTip(this.components);
            this.MainTabCtrl.SuspendLayout();
            this.PluginsPage.SuspendLayout();
            this.PreviewGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PluginsDataGrid)).BeginInit();
            this.MiscOptionsPage.SuspendLayout();
            this.AboutPage.SuspendLayout();
            this.AboutTableLayoutPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // ApplyBtn
            // 
            this.ApplyBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.ApplyBtn.Enabled = false;
            this.ApplyBtn.Location = new System.Drawing.Point(410, 533);
            this.ApplyBtn.Name = "ApplyBtn";
            this.ApplyBtn.Size = new System.Drawing.Size(75, 23);
            this.ApplyBtn.TabIndex = 4;
            this.ApplyBtn.Text = "&Apply";
            this.MainToolTip.SetToolTip(this.ApplyBtn, "Save changes made to the settings so far, leaving the window open");
            this.ApplyBtn.UseVisualStyleBackColor = true;
            this.ApplyBtn.Click += new System.EventHandler(this.ApplyBtn_Click);
            // 
            // OKBtn
            // 
            this.OKBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.OKBtn.Location = new System.Drawing.Point(248, 533);
            this.OKBtn.Name = "OKBtn";
            this.OKBtn.Size = new System.Drawing.Size(75, 23);
            this.OKBtn.TabIndex = 2;
            this.OKBtn.Text = "OK";
            this.MainToolTip.SetToolTip(this.OKBtn, "Save changes to settings and close the window");
            this.OKBtn.UseVisualStyleBackColor = true;
            this.OKBtn.Click += new System.EventHandler(this.OKBtn_Click);
            // 
            // CancelBtn
            // 
            this.CancelBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.CancelBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.CancelBtn.Location = new System.Drawing.Point(329, 533);
            this.CancelBtn.Name = "CancelBtn";
            this.CancelBtn.Size = new System.Drawing.Size(75, 23);
            this.CancelBtn.TabIndex = 3;
            this.CancelBtn.Text = "&Cancel";
            this.MainToolTip.SetToolTip(this.CancelBtn, "Cancel all changes made so far and close the window");
            this.CancelBtn.UseVisualStyleBackColor = true;
            this.CancelBtn.Click += new System.EventHandler(this.CancelBtn_Click);
            // 
            // MainTabCtrl
            // 
            this.MainTabCtrl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MainTabCtrl.Controls.Add(this.PluginsPage);
            this.MainTabCtrl.Controls.Add(this.MiscOptionsPage);
            this.MainTabCtrl.Controls.Add(this.AboutPage);
            this.MainTabCtrl.Location = new System.Drawing.Point(12, 12);
            this.MainTabCtrl.Name = "MainTabCtrl";
            this.MainTabCtrl.SelectedIndex = 0;
            this.MainTabCtrl.Size = new System.Drawing.Size(473, 515);
            this.MainTabCtrl.TabIndex = 0;
            // 
            // PluginsPage
            // 
            this.PluginsPage.Controls.Add(this.AddSeparatorBtn);
            this.PluginsPage.Controls.Add(this.ImportPipelinePluginsBtn);
            this.PluginsPage.Controls.Add(this.ExportPipelinePluginsBtn);
            this.PluginsPage.Controls.Add(this.BevelLineLbl2);
            this.PluginsPage.Controls.Add(this.RemovePipelinePluginBtn);
            this.PluginsPage.Controls.Add(this.EditPipelinePluginBtn);
            this.PluginsPage.Controls.Add(this.AddPipelinePluginBtn);
            this.PluginsPage.Controls.Add(this.BevelLineLbl);
            this.PluginsPage.Controls.Add(this.MovePluginDownBtn);
            this.PluginsPage.Controls.Add(this.MovePluginUpBtn);
            this.PluginsPage.Controls.Add(this.PreviewGroupBox);
            this.PluginsPage.Controls.Add(this.PluginsExplanationLbl2);
            this.PluginsPage.Controls.Add(this.PluginsDataGrid);
            this.PluginsPage.Controls.Add(this.PluginsExplanationLbl);
            this.PluginsPage.Location = new System.Drawing.Point(4, 22);
            this.PluginsPage.Name = "PluginsPage";
            this.PluginsPage.Padding = new System.Windows.Forms.Padding(3);
            this.PluginsPage.Size = new System.Drawing.Size(465, 489);
            this.PluginsPage.TabIndex = 1;
            this.PluginsPage.Text = "Commands";
            this.PluginsPage.UseVisualStyleBackColor = true;
            // 
            // AddSeparatorBtn
            // 
            this.AddSeparatorBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddSeparatorBtn.Location = new System.Drawing.Point(384, 139);
            this.AddSeparatorBtn.Name = "AddSeparatorBtn";
            this.AddSeparatorBtn.Size = new System.Drawing.Size(75, 23);
            this.AddSeparatorBtn.TabIndex = 8;
            this.AddSeparatorBtn.Text = "&Separator";
            this.MainToolTip.SetToolTip(this.AddSeparatorBtn, "Inserts a separator after the currently selected command");
            this.AddSeparatorBtn.UseVisualStyleBackColor = true;
            this.AddSeparatorBtn.Click += new System.EventHandler(this.AddSeparatorBtn_Click);
            // 
            // ImportPipelinePluginsBtn
            // 
            this.ImportPipelinePluginsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ImportPipelinePluginsBtn.Location = new System.Drawing.Point(384, 263);
            this.ImportPipelinePluginsBtn.Name = "ImportPipelinePluginsBtn";
            this.ImportPipelinePluginsBtn.Size = new System.Drawing.Size(75, 23);
            this.ImportPipelinePluginsBtn.TabIndex = 13;
            this.ImportPipelinePluginsBtn.Text = "&Import...";
            this.MainToolTip.SetToolTip(this.ImportPipelinePluginsBtn, "Imports custom commands from a file on disk");
            this.ImportPipelinePluginsBtn.UseVisualStyleBackColor = true;
            this.ImportPipelinePluginsBtn.Click += new System.EventHandler(this.ImportPipelinePluginsBtn_Click);
            // 
            // ExportPipelinePluginsBtn
            // 
            this.ExportPipelinePluginsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ExportPipelinePluginsBtn.Location = new System.Drawing.Point(384, 234);
            this.ExportPipelinePluginsBtn.Name = "ExportPipelinePluginsBtn";
            this.ExportPipelinePluginsBtn.Size = new System.Drawing.Size(75, 23);
            this.ExportPipelinePluginsBtn.TabIndex = 12;
            this.ExportPipelinePluginsBtn.Text = "Ex&port...";
            this.MainToolTip.SetToolTip(this.ExportPipelinePluginsBtn, "Exports the selected custom commands to a file on disk");
            this.ExportPipelinePluginsBtn.UseVisualStyleBackColor = true;
            this.ExportPipelinePluginsBtn.Click += new System.EventHandler(this.ExportPipelinePluginsBtn_Click);
            // 
            // BevelLineLbl2
            // 
            this.BevelLineLbl2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BevelLineLbl2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BevelLineLbl2.Location = new System.Drawing.Point(384, 226);
            this.BevelLineLbl2.Name = "BevelLineLbl2";
            this.BevelLineLbl2.Size = new System.Drawing.Size(75, 2);
            this.BevelLineLbl2.TabIndex = 11;
            // 
            // RemovePipelinePluginBtn
            // 
            this.RemovePipelinePluginBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.RemovePipelinePluginBtn.Location = new System.Drawing.Point(384, 197);
            this.RemovePipelinePluginBtn.Name = "RemovePipelinePluginBtn";
            this.RemovePipelinePluginBtn.Size = new System.Drawing.Size(75, 23);
            this.RemovePipelinePluginBtn.TabIndex = 10;
            this.RemovePipelinePluginBtn.Text = "&Remove";
            this.MainToolTip.SetToolTip(this.RemovePipelinePluginBtn, "Deletes the selected custom command");
            this.RemovePipelinePluginBtn.UseVisualStyleBackColor = true;
            this.RemovePipelinePluginBtn.Click += new System.EventHandler(this.RemovePipelinePluginBtn_Click);
            // 
            // EditPipelinePluginBtn
            // 
            this.EditPipelinePluginBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EditPipelinePluginBtn.Location = new System.Drawing.Point(384, 168);
            this.EditPipelinePluginBtn.Name = "EditPipelinePluginBtn";
            this.EditPipelinePluginBtn.Size = new System.Drawing.Size(75, 23);
            this.EditPipelinePluginBtn.TabIndex = 9;
            this.EditPipelinePluginBtn.Text = "&Edit...";
            this.MainToolTip.SetToolTip(this.EditPipelinePluginBtn, "Modifies the selected custom command");
            this.EditPipelinePluginBtn.UseVisualStyleBackColor = true;
            this.EditPipelinePluginBtn.Click += new System.EventHandler(this.EditPipelinePluginBtn_Click);
            // 
            // AddPipelinePluginBtn
            // 
            this.AddPipelinePluginBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddPipelinePluginBtn.Location = new System.Drawing.Point(384, 110);
            this.AddPipelinePluginBtn.Name = "AddPipelinePluginBtn";
            this.AddPipelinePluginBtn.Size = new System.Drawing.Size(75, 23);
            this.AddPipelinePluginBtn.TabIndex = 7;
            this.AddPipelinePluginBtn.Text = "&New...";
            this.MainToolTip.SetToolTip(this.AddPipelinePluginBtn, "Creates a new custom command");
            this.AddPipelinePluginBtn.UseVisualStyleBackColor = true;
            this.AddPipelinePluginBtn.Click += new System.EventHandler(this.AddPipelinePluginBtn_Click);
            // 
            // BevelLineLbl
            // 
            this.BevelLineLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BevelLineLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BevelLineLbl.Location = new System.Drawing.Point(384, 102);
            this.BevelLineLbl.Name = "BevelLineLbl";
            this.BevelLineLbl.Size = new System.Drawing.Size(75, 2);
            this.BevelLineLbl.TabIndex = 6;
            // 
            // MovePluginDownBtn
            // 
            this.MovePluginDownBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MovePluginDownBtn.Location = new System.Drawing.Point(384, 73);
            this.MovePluginDownBtn.Name = "MovePluginDownBtn";
            this.MovePluginDownBtn.Size = new System.Drawing.Size(75, 23);
            this.MovePluginDownBtn.TabIndex = 5;
            this.MovePluginDownBtn.Text = "&Down";
            this.MainToolTip.SetToolTip(this.MovePluginDownBtn, "Moves the selected command down one position");
            this.MovePluginDownBtn.UseVisualStyleBackColor = true;
            this.MovePluginDownBtn.Click += new System.EventHandler(this.MovePluginDownBtn_Click);
            // 
            // MovePluginUpBtn
            // 
            this.MovePluginUpBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.MovePluginUpBtn.Location = new System.Drawing.Point(384, 44);
            this.MovePluginUpBtn.Name = "MovePluginUpBtn";
            this.MovePluginUpBtn.Size = new System.Drawing.Size(75, 23);
            this.MovePluginUpBtn.TabIndex = 4;
            this.MovePluginUpBtn.Text = "&Up";
            this.MainToolTip.SetToolTip(this.MovePluginUpBtn, "Moves the selected command up one position");
            this.MovePluginUpBtn.UseVisualStyleBackColor = true;
            this.MovePluginUpBtn.Click += new System.EventHandler(this.MovePluginUpBtn_Click);
            // 
            // PreviewGroupBox
            // 
            this.PreviewGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PreviewGroupBox.Controls.Add(this.PreviewTxt);
            this.PreviewGroupBox.Location = new System.Drawing.Point(9, 430);
            this.PreviewGroupBox.Name = "PreviewGroupBox";
            this.PreviewGroupBox.Size = new System.Drawing.Size(369, 53);
            this.PreviewGroupBox.TabIndex = 3;
            this.PreviewGroupBox.TabStop = false;
            this.PreviewGroupBox.Text = "Preview";
            // 
            // PreviewTxt
            // 
            this.PreviewTxt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PreviewTxt.Location = new System.Drawing.Point(6, 19);
            this.PreviewTxt.Name = "PreviewTxt";
            this.PreviewTxt.ReadOnly = true;
            this.PreviewTxt.Size = new System.Drawing.Size(357, 20);
            this.PreviewTxt.TabIndex = 0;
            this.MainToolTip.SetToolTip(this.PreviewTxt, "Preview of the effect of the currently selected command when used");
            // 
            // PluginsExplanationLbl2
            // 
            this.PluginsExplanationLbl2.AutoSize = true;
            this.PluginsExplanationLbl2.Location = new System.Drawing.Point(6, 19);
            this.PluginsExplanationLbl2.Name = "PluginsExplanationLbl2";
            this.PluginsExplanationLbl2.Size = new System.Drawing.Size(429, 13);
            this.PluginsExplanationLbl2.TabIndex = 1;
            this.PluginsExplanationLbl2.Text = "well as Path Copy Copy\'s own submenu. You can also add, remove or reorder command" +
    "s.";
            // 
            // PluginsDataGrid
            // 
            this.PluginsDataGrid.AllowUserToAddRows = false;
            this.PluginsDataGrid.AllowUserToDeleteRows = false;
            this.PluginsDataGrid.AllowUserToResizeColumns = false;
            this.PluginsDataGrid.AllowUserToResizeRows = false;
            this.PluginsDataGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PluginsDataGrid.BackgroundColor = System.Drawing.SystemColors.Window;
            this.PluginsDataGrid.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.PluginsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.PluginsDataGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IconCol,
            this.PluginCol,
            this.InMainMenuCol,
            this.InSubmenuCol});
            this.PluginsDataGrid.Location = new System.Drawing.Point(9, 44);
            this.PluginsDataGrid.Name = "PluginsDataGrid";
            this.PluginsDataGrid.RowHeadersVisible = false;
            this.PluginsDataGrid.RowTemplate.Height = 18;
            this.PluginsDataGrid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.PluginsDataGrid.Size = new System.Drawing.Size(369, 380);
            this.PluginsDataGrid.TabIndex = 2;
            this.PluginsDataGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.PluginsDataGrid_CellContentClick);
            this.PluginsDataGrid.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.PluginsDataGrid_CellMouseEnter);
            this.PluginsDataGrid.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.PluginsDataGrid_CellValueChanged);
            this.PluginsDataGrid.CurrentCellDirtyStateChanged += new System.EventHandler(this.PluginsDataGrid_CurrentCellDirtyStateChanged);
            this.PluginsDataGrid.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.PluginsDataGrid_RowsAdded);
            this.PluginsDataGrid.SelectionChanged += new System.EventHandler(this.PluginsDataGrid_SelectionChanged);
            // 
            // IconCol
            // 
            this.IconCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.IconCol.HeaderText = "Icon";
            this.IconCol.Image = global::PathCopyCopy.Settings.Properties.Resources.BlankIcon;
            this.IconCol.MinimumWidth = 16;
            this.IconCol.Name = "IconCol";
            this.IconCol.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.IconCol.Width = 34;
            // 
            // PluginCol
            // 
            this.PluginCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PluginCol.DataPropertyName = "Name";
            this.PluginCol.HeaderText = "Command";
            this.PluginCol.Name = "PluginCol";
            this.PluginCol.ReadOnly = true;
            this.PluginCol.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.PluginCol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // InMainMenuCol
            // 
            this.InMainMenuCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.InMainMenuCol.DataPropertyName = "ShowInMainMenuStr";
            this.InMainMenuCol.HeaderText = "Main menu";
            this.InMainMenuCol.Name = "InMainMenuCol";
            this.InMainMenuCol.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.InMainMenuCol.Width = 65;
            // 
            // InSubmenuCol
            // 
            this.InSubmenuCol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.InSubmenuCol.DataPropertyName = "ShowInSubmenuStr";
            this.InSubmenuCol.HeaderText = "Submenu";
            this.InSubmenuCol.Name = "InSubmenuCol";
            this.InSubmenuCol.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.InSubmenuCol.Width = 58;
            // 
            // PluginsExplanationLbl
            // 
            this.PluginsExplanationLbl.AutoSize = true;
            this.PluginsExplanationLbl.Location = new System.Drawing.Point(6, 6);
            this.PluginsExplanationLbl.Name = "PluginsExplanationLbl";
            this.PluginsExplanationLbl.Size = new System.Drawing.Size(439, 13);
            this.PluginsExplanationLbl.TabIndex = 0;
            this.PluginsExplanationLbl.Text = "Here, you can choose which commands are shown in the main Explorer contextual men" +
    "u as";
            // 
            // MiscOptionsPage
            // 
            this.MiscOptionsPage.Controls.Add(this.EncodeURICharsChk);
            this.MiscOptionsPage.Controls.Add(this.EncodeURIWhitespaceChk);
            this.MiscOptionsPage.Controls.Add(this.CopyOnSameLineChk);
            this.MiscOptionsPage.Controls.Add(this.DropRedundantWordsChk);
            this.MiscOptionsPage.Controls.Add(this.UsePreviewModeChk);
            this.MiscOptionsPage.Controls.Add(this.UseIconForSubmenuChk);
            this.MiscOptionsPage.Controls.Add(this.EmailLinksChk);
            this.MiscOptionsPage.Controls.Add(this.EnableSoftwareUpdateChk);
            this.MiscOptionsPage.Controls.Add(this.AlwaysShowSubmenuChk);
            this.MiscOptionsPage.Controls.Add(this.HiddenSharesChk);
            this.MiscOptionsPage.Controls.Add(this.AddQuotesChk);
            this.MiscOptionsPage.Location = new System.Drawing.Point(4, 22);
            this.MiscOptionsPage.Name = "MiscOptionsPage";
            this.MiscOptionsPage.Padding = new System.Windows.Forms.Padding(3);
            this.MiscOptionsPage.Size = new System.Drawing.Size(465, 489);
            this.MiscOptionsPage.TabIndex = 0;
            this.MiscOptionsPage.Text = "Options";
            this.MiscOptionsPage.UseVisualStyleBackColor = true;
            // 
            // EncodeURICharsChk
            // 
            this.EncodeURICharsChk.AutoSize = true;
            this.EncodeURICharsChk.Enabled = false;
            this.EncodeURICharsChk.Location = new System.Drawing.Point(25, 75);
            this.EncodeURICharsChk.Name = "EncodeURICharsChk";
            this.EncodeURICharsChk.Size = new System.Drawing.Size(225, 17);
            this.EncodeURICharsChk.TabIndex = 3;
            this.EncodeURICharsChk.Text = "...and all in&valid URI characters (e.g., %xx)";
            this.MainToolTip.SetToolTip(this.EncodeURICharsChk, "Replaces all characters in copied paths that are invalid in a URI by percent-enco" +
        "ding ( %xx )");
            this.EncodeURICharsChk.UseVisualStyleBackColor = true;
            // 
            // EncodeURIWhitespaceChk
            // 
            this.EncodeURIWhitespaceChk.AutoSize = true;
            this.EncodeURIWhitespaceChk.Location = new System.Drawing.Point(6, 52);
            this.EncodeURIWhitespaceChk.Name = "EncodeURIWhitespaceChk";
            this.EncodeURIWhitespaceChk.Size = new System.Drawing.Size(287, 17);
            this.EncodeURIWhitespaceChk.TabIndex = 2;
            this.EncodeURIWhitespaceChk.Text = "Encode &whitespace using percent-encoding (e.g., %20)";
            this.MainToolTip.SetToolTip(this.EncodeURIWhitespaceChk, "Encodes all whitespace characters in paths, replacing them with %20");
            this.EncodeURIWhitespaceChk.UseVisualStyleBackColor = true;
            this.EncodeURIWhitespaceChk.CheckedChanged += new System.EventHandler(this.EncodeURIWhitespaceChk_CheckedChanged);
            // 
            // CopyOnSameLineChk
            // 
            this.CopyOnSameLineChk.AutoSize = true;
            this.CopyOnSameLineChk.Location = new System.Drawing.Point(6, 213);
            this.CopyOnSameLineChk.Name = "CopyOnSameLineChk";
            this.CopyOnSameLineChk.Size = new System.Drawing.Size(197, 17);
            this.CopyOnSameLineChk.TabIndex = 9;
            this.CopyOnSameLineChk.Text = "Copy mul&tiple paths on the same line";
            this.MainToolTip.SetToolTip(this.CopyOnSameLineChk, "When copying paths of multiple selected files/folders, copy them all on the same " +
        "line (separating them with whitespace) instead of copying them on different line" +
        "s (separated with newlines)");
            this.CopyOnSameLineChk.UseVisualStyleBackColor = true;
            // 
            // DropRedundantWordsChk
            // 
            this.DropRedundantWordsChk.AutoSize = true;
            this.DropRedundantWordsChk.Location = new System.Drawing.Point(6, 190);
            this.DropRedundantWordsChk.Name = "DropRedundantWordsChk";
            this.DropRedundantWordsChk.Size = new System.Drawing.Size(341, 17);
            this.DropRedundantWordsChk.TabIndex = 8;
            this.DropRedundantWordsChk.Text = "Drop &redundant words like \"Copy\" or \"Long/Short\" in the submenu";
            this.MainToolTip.SetToolTip(this.DropRedundantWordsChk, "Drops some redundant words when displaying commands in the submenu");
            this.DropRedundantWordsChk.UseVisualStyleBackColor = true;
            // 
            // UsePreviewModeChk
            // 
            this.UsePreviewModeChk.AutoSize = true;
            this.UsePreviewModeChk.Location = new System.Drawing.Point(6, 167);
            this.UsePreviewModeChk.Name = "UsePreviewModeChk";
            this.UsePreviewModeChk.Size = new System.Drawing.Size(312, 17);
            this.UsePreviewModeChk.TabIndex = 7;
            this.UsePreviewModeChk.Text = "Show &previews instead of command descriptions in submenu";
            this.MainToolTip.SetToolTip(this.UsePreviewModeChk, "When displaying commands in the submenu, show previews of what copied paths would" +
        " look like if such commands were selected");
            this.UsePreviewModeChk.UseVisualStyleBackColor = true;
            // 
            // UseIconForSubmenuChk
            // 
            this.UseIconForSubmenuChk.AutoSize = true;
            this.UseIconForSubmenuChk.Location = new System.Drawing.Point(6, 144);
            this.UseIconForSubmenuChk.Name = "UseIconForSubmenuChk";
            this.UseIconForSubmenuChk.Size = new System.Drawing.Size(157, 17);
            this.UseIconForSubmenuChk.TabIndex = 6;
            this.UseIconForSubmenuChk.Text = "Show &icon next to submenu";
            this.MainToolTip.SetToolTip(this.UseIconForSubmenuChk, "Displays a Path Copy Copy icon next to the submenu in Explorer\'s contextual menu");
            this.UseIconForSubmenuChk.UseVisualStyleBackColor = true;
            // 
            // EmailLinksChk
            // 
            this.EmailLinksChk.AutoSize = true;
            this.EmailLinksChk.Location = new System.Drawing.Point(6, 29);
            this.EmailLinksChk.Name = "EmailLinksChk";
            this.EmailLinksChk.Size = new System.Drawing.Size(289, 17);
            this.EmailLinksChk.TabIndex = 1;
            this.EmailLinksChk.Text = "Add < and > around copied paths (to create e-&mail links)";
            this.MainToolTip.SetToolTip(this.EmailLinksChk, "Surrounds all copied paths with < and > characters (this creates e-mail links)");
            this.EmailLinksChk.UseVisualStyleBackColor = true;
            // 
            // EnableSoftwareUpdateChk
            // 
            this.EnableSoftwareUpdateChk.AutoSize = true;
            this.EnableSoftwareUpdateChk.Location = new System.Drawing.Point(6, 236);
            this.EnableSoftwareUpdateChk.Name = "EnableSoftwareUpdateChk";
            this.EnableSoftwareUpdateChk.Size = new System.Drawing.Size(177, 17);
            this.EnableSoftwareUpdateChk.TabIndex = 10;
            this.EnableSoftwareUpdateChk.Text = "Check for &updates automatically";
            this.MainToolTip.SetToolTip(this.EnableSoftwareUpdateChk, "Automatically check for new versions of Path Copy Copy and offer them when they a" +
        "re released");
            this.EnableSoftwareUpdateChk.UseVisualStyleBackColor = true;
            // 
            // AlwaysShowSubmenuChk
            // 
            this.AlwaysShowSubmenuChk.AutoSize = true;
            this.AlwaysShowSubmenuChk.Location = new System.Drawing.Point(6, 121);
            this.AlwaysShowSubmenuChk.Name = "AlwaysShowSubmenuChk";
            this.AlwaysShowSubmenuChk.Size = new System.Drawing.Size(133, 17);
            this.AlwaysShowSubmenuChk.TabIndex = 5;
            this.AlwaysShowSubmenuChk.Text = "A&lways show submenu";
            this.MainToolTip.SetToolTip(this.AlwaysShowSubmenuChk, "Always display the Path Copy Copy submenu in the Explorer contextual menu (otherw" +
        "ise, only display it when the Shift key is held down)");
            this.AlwaysShowSubmenuChk.UseVisualStyleBackColor = true;
            // 
            // HiddenSharesChk
            // 
            this.HiddenSharesChk.AutoSize = true;
            this.HiddenSharesChk.Location = new System.Drawing.Point(6, 98);
            this.HiddenSharesChk.Name = "HiddenSharesChk";
            this.HiddenSharesChk.Size = new System.Drawing.Size(238, 17);
            this.HiddenSharesChk.TabIndex = 4;
            this.HiddenSharesChk.Text = "Use &hidden shares when copying UNC paths";
            this.MainToolTip.SetToolTip(this.HiddenSharesChk, "Considers hidden shares (shares ending with the $ character, including administra" +
        "tive shares like \\\\server\\C$) when copying UNC paths");
            this.HiddenSharesChk.UseVisualStyleBackColor = true;
            // 
            // AddQuotesChk
            // 
            this.AddQuotesChk.AutoSize = true;
            this.AddQuotesChk.Location = new System.Drawing.Point(6, 6);
            this.AddQuotesChk.Name = "AddQuotesChk";
            this.AddQuotesChk.Size = new System.Drawing.Size(180, 17);
            this.AddQuotesChk.TabIndex = 0;
            this.AddQuotesChk.Text = "Add &quotes around copied paths";
            this.MainToolTip.SetToolTip(this.AddQuotesChk, "Surrounds all copied paths with quotes ( \" )");
            this.AddQuotesChk.UseVisualStyleBackColor = true;
            // 
            // AboutPage
            // 
            this.AboutPage.Controls.Add(this.AboutTableLayoutPanel);
            this.AboutPage.Location = new System.Drawing.Point(4, 22);
            this.AboutPage.Name = "AboutPage";
            this.AboutPage.Padding = new System.Windows.Forms.Padding(3);
            this.AboutPage.Size = new System.Drawing.Size(465, 489);
            this.AboutPage.TabIndex = 4;
            this.AboutPage.Text = "About";
            this.AboutPage.UseVisualStyleBackColor = true;
            // 
            // AboutTableLayoutPanel
            // 
            this.AboutTableLayoutPanel.ColumnCount = 1;
            this.AboutTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.AboutTableLayoutPanel.Controls.Add(this.ProductAndVersionLbl, 0, 0);
            this.AboutTableLayoutPanel.Controls.Add(this.CopyrightLbl, 0, 1);
            this.AboutTableLayoutPanel.Controls.Add(this.VisitWebsiteLbl, 0, 2);
            this.AboutTableLayoutPanel.Controls.Add(this.SiteLinkLbl, 0, 3);
            this.AboutTableLayoutPanel.Controls.Add(this.LicenseExplanationLbl, 0, 4);
            this.AboutTableLayoutPanel.Controls.Add(this.LicenseTxtLinkLbl, 0, 5);
            this.AboutTableLayoutPanel.Controls.Add(this.DonationLinkLbl, 0, 6);
            this.AboutTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.AboutTableLayoutPanel.Location = new System.Drawing.Point(3, 3);
            this.AboutTableLayoutPanel.Name = "AboutTableLayoutPanel";
            this.AboutTableLayoutPanel.RowCount = 7;
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.AboutTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.AboutTableLayoutPanel.Size = new System.Drawing.Size(459, 483);
            this.AboutTableLayoutPanel.TabIndex = 0;
            // 
            // ProductAndVersionLbl
            // 
            this.ProductAndVersionLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ProductAndVersionLbl.AutoSize = true;
            this.ProductAndVersionLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ProductAndVersionLbl.Location = new System.Drawing.Point(3, 0);
            this.ProductAndVersionLbl.Name = "ProductAndVersionLbl";
            this.ProductAndVersionLbl.Size = new System.Drawing.Size(453, 80);
            this.ProductAndVersionLbl.TabIndex = 0;
            this.ProductAndVersionLbl.Text = "Path Copy Copy {0}";
            this.ProductAndVersionLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CopyrightLbl
            // 
            this.CopyrightLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CopyrightLbl.AutoSize = true;
            this.CopyrightLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CopyrightLbl.Location = new System.Drawing.Point(3, 80);
            this.CopyrightLbl.Name = "CopyrightLbl";
            this.CopyrightLbl.Size = new System.Drawing.Size(453, 80);
            this.CopyrightLbl.TabIndex = 1;
            this.CopyrightLbl.Text = "{1}";
            this.CopyrightLbl.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // VisitWebsiteLbl
            // 
            this.VisitWebsiteLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.VisitWebsiteLbl.AutoSize = true;
            this.VisitWebsiteLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VisitWebsiteLbl.Location = new System.Drawing.Point(3, 160);
            this.VisitWebsiteLbl.Name = "VisitWebsiteLbl";
            this.VisitWebsiteLbl.Size = new System.Drawing.Size(453, 40);
            this.VisitWebsiteLbl.TabIndex = 2;
            this.VisitWebsiteLbl.Text = "Visit our website:";
            this.VisitWebsiteLbl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // SiteLinkLbl
            // 
            this.SiteLinkLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SiteLinkLbl.AutoSize = true;
            this.SiteLinkLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SiteLinkLbl.Location = new System.Drawing.Point(3, 200);
            this.SiteLinkLbl.Name = "SiteLinkLbl";
            this.SiteLinkLbl.Size = new System.Drawing.Size(453, 60);
            this.SiteLinkLbl.TabIndex = 3;
            this.SiteLinkLbl.TabStop = true;
            this.SiteLinkLbl.Text = "https://pathcopycopy.github.io/";
            this.SiteLinkLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SiteLinkLbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.SiteLinkLbl_LinkClicked);
            // 
            // LicenseExplanationLbl
            // 
            this.LicenseExplanationLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LicenseExplanationLbl.AutoSize = true;
            this.LicenseExplanationLbl.Location = new System.Drawing.Point(3, 260);
            this.LicenseExplanationLbl.Name = "LicenseExplanationLbl";
            this.LicenseExplanationLbl.Size = new System.Drawing.Size(453, 40);
            this.LicenseExplanationLbl.TabIndex = 4;
            this.LicenseExplanationLbl.Text = "Path Copy Copy is free software and is distributed under\r\nthe MIT License. For mo" +
    "re information, please see";
            this.LicenseExplanationLbl.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // LicenseTxtLinkLbl
            // 
            this.LicenseTxtLinkLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.LicenseTxtLinkLbl.AutoSize = true;
            this.LicenseTxtLinkLbl.Location = new System.Drawing.Point(3, 300);
            this.LicenseTxtLinkLbl.Name = "LicenseTxtLinkLbl";
            this.LicenseTxtLinkLbl.Size = new System.Drawing.Size(453, 60);
            this.LicenseTxtLinkLbl.TabIndex = 5;
            this.LicenseTxtLinkLbl.TabStop = true;
            this.LicenseTxtLinkLbl.Text = "LICENSE";
            this.LicenseTxtLinkLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.LicenseTxtLinkLbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.LicenseTxtLinkLbl_LinkClicked);
            // 
            // DonationLinkLbl
            // 
            this.DonationLinkLbl.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DonationLinkLbl.AutoSize = true;
            this.DonationLinkLbl.LinkArea = new System.Windows.Forms.LinkArea(46, 6);
            this.DonationLinkLbl.Location = new System.Drawing.Point(3, 360);
            this.DonationLinkLbl.Name = "DonationLinkLbl";
            this.DonationLinkLbl.Size = new System.Drawing.Size(453, 30);
            this.DonationLinkLbl.TabIndex = 6;
            this.DonationLinkLbl.TabStop = true;
            this.DonationLinkLbl.Text = "If you like Path Copy Copy, don\'t hesitate to DONATE through PayPal!\r\nDonations h" +
    "elp fund future development and provide responsive support.";
            this.DonationLinkLbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DonationLinkLbl.UseCompatibleTextRendering = true;
            this.DonationLinkLbl.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.DonationLinkLbl_LinkClicked);
            // 
            // ExportPipelinePluginsSaveDlg
            // 
            this.ExportPipelinePluginsSaveDlg.DefaultExt = "ecc";
            this.ExportPipelinePluginsSaveDlg.Filter = "Exported custom commands (*.ecc)|*.ecc|Exported custom commands (pre-12.0) (*.pcc" +
    "pp)|*.pccpp";
            // 
            // ImportPipelinePluginsOpenDlg
            // 
            this.ImportPipelinePluginsOpenDlg.DefaultExt = "ecc";
            this.ImportPipelinePluginsOpenDlg.Filter = "Exported custom commands (*.ecc;*.pccpp)|*.ecc;*.pccpp";
            // 
            // ChoosePluginIconOpenDlg
            // 
            this.ChoosePluginIconOpenDlg.Filter = "Image files (*.bmp;*.jpg;*.gif;*.png;*.ico)|*.bmp;*.jpg;*.gif;*.png;*.ico|All fil" +
    "es (*.*)|*.*";
            // 
            // ExportUserSettingsSaveDlg
            // 
            this.ExportUserSettingsSaveDlg.DefaultExt = "reg";
            this.ExportUserSettingsSaveDlg.Filter = "Exported user settings (*.reg)|*.reg";
            this.ExportUserSettingsSaveDlg.Title = "Export Settings As";
            // 
            // ExportUserSettingsBtn
            // 
            this.ExportUserSettingsBtn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ExportUserSettingsBtn.Location = new System.Drawing.Point(12, 533);
            this.ExportUserSettingsBtn.Name = "ExportUserSettingsBtn";
            this.ExportUserSettingsBtn.Size = new System.Drawing.Size(107, 23);
            this.ExportUserSettingsBtn.TabIndex = 1;
            this.ExportUserSettingsBtn.Text = "E&xport Settings...";
            this.MainToolTip.SetToolTip(this.ExportUserSettingsBtn, "Export all settings to a file on disk");
            this.ExportUserSettingsBtn.UseVisualStyleBackColor = true;
            this.ExportUserSettingsBtn.Click += new System.EventHandler(this.ExportUserSettingsBtn_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.OKBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.CancelBtn;
            this.ClientSize = new System.Drawing.Size(497, 568);
            this.Controls.Add(this.ExportUserSettingsBtn);
            this.Controls.Add(this.MainTabCtrl);
            this.Controls.Add(this.CancelBtn);
            this.Controls.Add(this.OKBtn);
            this.Controls.Add(this.ApplyBtn);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(505, 595);
            this.Name = "MainForm";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Path Copy Copy";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.LocationChanged += new System.EventHandler(this.MainForm_LocationChanged);
            this.SizeChanged += new System.EventHandler(this.MainForm_SizeChanged);
            this.MainTabCtrl.ResumeLayout(false);
            this.PluginsPage.ResumeLayout(false);
            this.PluginsPage.PerformLayout();
            this.PreviewGroupBox.ResumeLayout(false);
            this.PreviewGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PluginsDataGrid)).EndInit();
            this.MiscOptionsPage.ResumeLayout(false);
            this.MiscOptionsPage.PerformLayout();
            this.AboutPage.ResumeLayout(false);
            this.AboutTableLayoutPanel.ResumeLayout(false);
            this.AboutTableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ApplyBtn;
        private System.Windows.Forms.Button OKBtn;
        private System.Windows.Forms.Button CancelBtn;
        private System.Windows.Forms.TabControl MainTabCtrl;
        private System.Windows.Forms.TabPage MiscOptionsPage;
        private System.Windows.Forms.TabPage PluginsPage;
        private System.Windows.Forms.CheckBox AddQuotesChk;
        private System.Windows.Forms.CheckBox HiddenSharesChk;
        private System.Windows.Forms.CheckBox AlwaysShowSubmenuChk;
        private System.Windows.Forms.Label PluginsExplanationLbl;
        private System.Windows.Forms.SaveFileDialog ExportPipelinePluginsSaveDlg;
        private System.Windows.Forms.OpenFileDialog ImportPipelinePluginsOpenDlg;
        private System.Windows.Forms.TabPage AboutPage;
        private System.Windows.Forms.TableLayoutPanel AboutTableLayoutPanel;
        private System.Windows.Forms.Label ProductAndVersionLbl;
        private System.Windows.Forms.Label CopyrightLbl;
        private System.Windows.Forms.Label VisitWebsiteLbl;
        private System.Windows.Forms.LinkLabel SiteLinkLbl;
        private System.Windows.Forms.Label LicenseExplanationLbl;
        private System.Windows.Forms.LinkLabel LicenseTxtLinkLbl;
        private System.Windows.Forms.LinkLabel DonationLinkLbl;
        private System.Windows.Forms.CheckBox EnableSoftwareUpdateChk;
        private System.Windows.Forms.CheckBox UseIconForSubmenuChk;
        private System.Windows.Forms.CheckBox EmailLinksChk;
        private System.Windows.Forms.CheckBox UsePreviewModeChk;
        private System.Windows.Forms.CheckBox DropRedundantWordsChk;
        private System.Windows.Forms.OpenFileDialog ChoosePluginIconOpenDlg;
        private System.Windows.Forms.CheckBox CopyOnSameLineChk;
        private System.Windows.Forms.CheckBox EncodeURIWhitespaceChk;
        private System.Windows.Forms.CheckBox EncodeURICharsChk;
        private System.Windows.Forms.SaveFileDialog ExportUserSettingsSaveDlg;
        private System.Windows.Forms.Button ExportUserSettingsBtn;
        private System.Windows.Forms.ToolTip MainToolTip;
        private System.Windows.Forms.Label PluginsExplanationLbl2;
        private System.Windows.Forms.DataGridView PluginsDataGrid;
        private System.Windows.Forms.GroupBox PreviewGroupBox;
        private System.Windows.Forms.TextBox PreviewTxt;
        private System.Windows.Forms.Button ImportPipelinePluginsBtn;
        private System.Windows.Forms.Button ExportPipelinePluginsBtn;
        private System.Windows.Forms.Label BevelLineLbl2;
        private System.Windows.Forms.Button RemovePipelinePluginBtn;
        private System.Windows.Forms.Button EditPipelinePluginBtn;
        private System.Windows.Forms.Button AddPipelinePluginBtn;
        private System.Windows.Forms.Label BevelLineLbl;
        private System.Windows.Forms.Button MovePluginDownBtn;
        private System.Windows.Forms.Button MovePluginUpBtn;
        private System.Windows.Forms.DataGridViewImageColumn IconCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn PluginCol;
        private System.Windows.Forms.DataGridViewCheckBoxColumn InMainMenuCol;
        private System.Windows.Forms.DataGridViewCheckBoxColumn InSubmenuCol;
        private System.Windows.Forms.Button AddSeparatorBtn;
    }
}

